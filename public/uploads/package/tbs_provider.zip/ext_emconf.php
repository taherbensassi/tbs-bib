<?php

/**
 * Extension Manager/Repository config file for ext "tbs_provider".
 */
$EM_CONF[$_EXTKEY] = [
    'title' => 'Tbs Provider',
    'description' => '',
    'category' => 'templates',
    'constraints' => [
        'depends' => [
            'typo3' => '8.7.0-8.7.99',
            'fluid_styled_content' => '8.7.0-8.7.99',
            'rte_ckeditor' => '8.7.0-8.7.99',
        ],
        'conflicts' => [
        ],
    ],
    'autoload' => [
        'psr-4' => [
            'TheBrettinghams\\TbsProvider\\' => 'Classes',
        ],
    ],
    'state' => 'stable',
    'uploadfolder' => 0,
    'createDirs' => '',
    'clearCacheOnLoad' => 1,
    'author' => 'taher.bensassi@brettingham.de',
    'author_email' => 'taher.bensassi@brettingham.de',
    'author_company' => 'THE BRETTINGHAMS',
    'version' => '1.0.0',
];
