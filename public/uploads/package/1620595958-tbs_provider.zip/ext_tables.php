<?php
defined('TYPO3_MODE') || die();
