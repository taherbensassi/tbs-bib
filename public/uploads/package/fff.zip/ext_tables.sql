#
# Add SQL definition of database tables
#
