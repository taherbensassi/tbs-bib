<?php

/**
 * Extension Manager/Repository config file for ext "fff".
 */
$EM_CONF[$_EXTKEY] = [
    'title' => 'fff',
    'description' => '',
    'category' => 'templates',
    'constraints' => [
        'depends' => [
            'bootstrap_package' => '10.0.0-11.0.99',
        ],
        'conflicts' => [
        ],
    ],
    'autoload' => [
        'psr-4' => [
            'TheBrettinghams\\Fff\\' => 'Classes',
        ],
    ],
    'state' => 'stable',
    'uploadfolder' => 0,
    'createDirs' => '',
    'clearCacheOnLoad' => 1,
    'author' => 'taher.bensassi@brettingham.de',
    'author_email' => 'taher.bensassi@brettingham.de',
    'author_company' => 'THE BRETTINGHAMS',
    'version' => '1.0.0',
];
