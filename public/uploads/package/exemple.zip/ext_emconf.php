<?php

/**
 * Extension Manager/Repository config file for ext "exemple".
 */
$EM_CONF[$_EXTKEY] = [
    'title' => 'Exemple',
    'description' => '',
    'category' => 'templates',
    'constraints' => [
        'depends' => [
            'bootstrap_package' => '10.0.0-10.0.99',
        ],
        'conflicts' => [
        ],
    ],
    'autoload' => [
        'psr-4' => [
            'TheBrettinghams\\Exemple\\' => 'Classes',
        ],
    ],
    'state' => 'stable',
    'uploadfolder' => 0,
    'createDirs' => '',
    'clearCacheOnLoad' => 1,
    'author' => 'taher.bensassi@brettingham.de',
    'author_email' => 'taher.bensassi@brettingham.de',
    'author_company' => 'THE BRETTINGHAMS',
    'version' => '1.0.0',
];
