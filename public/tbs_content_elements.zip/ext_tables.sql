CREATE TABLE tt_content (

tx_tbs_contentelements_image_width tinytext,
tx_tbs_contentelements_image_alignment tinytext,


);