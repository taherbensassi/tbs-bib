<?php

$imageAllowedFileExtensions = 'gif,jpg,jpeg,bmp,png,svg';
$imageDisallowedFileExtensions = 'tif,tiff,pcx,pdf,ai';

/** new table fields **/
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns(
    'tt_content',
    array(
        'tx_tbs_contentelements_image_width' => array(
            'label' => 'LLL:EXT:tbs_content_elements/Resources/Private/Language/locallang.xlf:tx_tbs_contentelements_image_width',
            'l10n_mode' => 'mergeIfNotBlank',
            'exclude' => 1,
            'config' => array(
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    ['LLL:EXT:tbs_content_elements/Resources/Private/Language/locallang.xlf:tx_tbs_contentelements_image_width.I', '0'],
                    ['LLL:EXT:tbs_content_elements/Resources/Private/Language/locallang.xlf:tx_tbs_contentelements_image_width.II', '1'],
                    ['LLL:EXT:tbs_content_elements/Resources/Private/Language/locallang.xlf:tx_tbs_contentelements_image_width.III', '2'],

                ],
                'size' => '1',
            )
        ),
        'tx_tbs_contentelements_image_alignment' => array(
            'label' => 'LLL:EXT:tbs_content_elements/Resources/Private/Language/locallang.xlf:tx_tbs_contentelements_image_alignment',
            'l10n_mode' => 'mergeIfNotBlank',
            'exclude' => 1,
            'config' => array(
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    ['LLL:EXT:tbs_content_elements/Resources/Private/Language/locallang.xlf:tx_tbs_contentelements_image_alignment.I', 'left'],
                    ['LLL:EXT:tbs_content_elements/Resources/Private/Language/locallang.xlf:tx_tbs_contentelements_image_alignment.II', 'right'],
                ],
                'size' => '1',
            )
        ),
    )
);

/**  Image content Element  **/
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPlugin(
    array(
        'LLL:EXT:tbs_content_elements/Resources/Private/Language/locallang.xlf:tbscontentelements_imagecontent.wizard.title',
        'tbscontentelements_imagecontent',
        'tbscontentelements_imagecontent'
    ),
    'CType',
    'tbs_content_elements'
);


$GLOBALS['TCA']['tt_content']['types']['tbscontentelements_imagecontent'] = array(
    'showitem' => '
      --div--;LLL:EXT:core/Resources/Private/Language/Form/locallang_tabs.xlf:general,
         --palette--;;general,
         tx_tbs_contentelements_image_alignment,
         tx_tbs_contentelements_image_width,
         image,
   ',
    'columnsOverrides' => [
        'image' =>[
            'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig('image', [
                'overrideChildTca' => [
                    'types' => [
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_IMAGE => [
                            'showitem' => 'LLL:EXT:lang/Resources/Private/Language/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette;--linebreak--,title,alternative,description,after:description,
                             --palette--;;filePalette'
                        ],
                    ],
                ],
                'minitems' => 1,
                'maxitems' => 1,
            ],$imageAllowedFileExtensions,$imageDisallowedFileExtensions),
        ],
    ]
);